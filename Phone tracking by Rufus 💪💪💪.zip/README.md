# Phone tracking

A small, privacy-first lost-phone helper. It directs people to official device-finding services and official account-security resources, and provides a recovery checklist that is saved locally in the browser.

## What it does

- Links to Apple Find Devices, Google Find Hub, and Samsung Find.
- Links to official recovery/security pages for common social and platform accounts.
- Saves checklist progress in the current browser using `localStorage`.
- Includes a reset and clear-data action.

## What it does not do

- It does not locate or track a phone itself.
- It does not collect GPS data, social media activity, credentials, or personal details.
- It does not track other people. Use official locator tools only for devices you own or are authorized to manage.

## Run locally

No build step or dependencies are needed. Open `index.html` in a modern browser, or serve this folder with any static file server. For example:

```sh
python3 -m http.server 8000
```

Then visit <http://localhost:8000>.

The checklist is stored only in the browser profile where the page is used. Clearing site data in the browser also removes it.
