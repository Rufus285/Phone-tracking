(() => {
  'use strict';

  const STORAGE_KEY = 'phone-tracking-checklist-v1';
  const checkboxes = Array.from(document.querySelectorAll('#checklist input[type="checkbox"]'));
  const progressLabel = document.getElementById('progress-label');
  const progressFill = document.getElementById('progress-fill');
  const progressBar = document.querySelector('[role="progressbar"]');
  const statusMessage = document.getElementById('status-message');

  function readSavedState() {
    try {
      const parsed = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || '{}');
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    } catch (_error) {
      return {};
    }
  }

  function saveState() {
    const state = {};
    checkboxes.forEach((checkbox) => { state[checkbox.dataset.id] = checkbox.checked; });
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      statusMessage.textContent = 'Checklist saved in this browser.';
      window.setTimeout(() => { statusMessage.textContent = ''; }, 2500);
    } catch (_error) {
      statusMessage.textContent = 'Could not save in this browser. Your changes remain until you leave.';
    }
    updateProgress();
  }

  function updateProgress() {
    const completed = checkboxes.filter((checkbox) => checkbox.checked).length;
    const total = checkboxes.length;
    progressLabel.textContent = `${completed} of ${total} complete`;
    progressFill.style.width = `${total ? (completed / total) * 100 : 0}%`;
    progressBar.setAttribute('aria-valuenow', String(completed));
  }

  const savedState = readSavedState();
  checkboxes.forEach((checkbox) => {
    checkbox.checked = savedState[checkbox.dataset.id] === true;
    checkbox.addEventListener('change', saveState);
  });
  updateProgress();

  document.getElementById('reset-checklist').addEventListener('click', () => {
    checkboxes.forEach((checkbox) => { checkbox.checked = false; });
    saveState();
    statusMessage.textContent = 'Checklist reset.';
  });

  document.getElementById('clear-data').addEventListener('click', () => {
    try {
      window.localStorage.removeItem(STORAGE_KEY);
      checkboxes.forEach((checkbox) => { checkbox.checked = false; });
      updateProgress();
      statusMessage.textContent = 'Saved checklist data cleared from this browser.';
    } catch (_error) {
      statusMessage.textContent = 'The browser could not clear saved data.';
    }
  });
})();
